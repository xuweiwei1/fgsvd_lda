The compressed file mainly contains the FGsvd-LDA algorithm and the FTRLDA algorithm [1], both of which are fast solutions for LDA under high-dimensional small-sample problems. In addition, the data folder contains image data and text data for testing.

Please pay attention to the selection of the subspace and the choice of image size.


[1] Yujie Wang, Weiwei Xu* and Lei Zhu, Efficient Linear Discriminant Analysis based on Randomized Low-Rank Approaches, IEEE Transactions on Neural Networks and Learning Systems